# Arjun Pradeep – Portfolio Website

A modern, dark-themed portfolio site built with HTML, CSS & vanilla JS.

## 🚀 Deploy to GitHub Pages (5 minutes)

1. Go to [github.com](https://github.com) → **New repository**
2. Name it: `arjunpradeep.github.io` (or any name)
3. Set to **Public**, click **Create repository**
4. Upload `index.html` via the GitHub web interface (drag & drop)
5. Go to **Settings → Pages**
6. Under **Source**, select `main` branch → `/root` → **Save**
7. Your site will be live at `https://arjunpradeep.github.io` within 1–2 minutes ✅

## 📁 Files
- `index.html` – The complete portfolio (single file, no dependencies)
